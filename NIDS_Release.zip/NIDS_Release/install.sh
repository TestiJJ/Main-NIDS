#!/bin/bash
echo "🛡️ Installing Project NIDS Sensor..."

# Detect Operating System
OS="$(uname -s)"

if [ "$OS" = "Linux" ]; then
    echo "[*] Detected Linux environment."
    sudo apt update && sudo apt install -y suricata python3 python3-pip

elif [ "$OS" = "Darwin" ]; then
    echo "[*] Detected macOS environment."
    # Check if Homebrew is installed, install if missing
    if ! command -v brew &> /dev/null; then
        echo "[*] Homebrew not found. Installing Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    brew update
    brew install suricata python3
else
    echo "[!] Unsupported operating system: $OS"
    exit 1
fi

# Create working directory and deploy components
sudo mkdir -p /opt/nids_agent
sudo cp nids_bridge.py /opt/nids_agent/
if [ -f "requirements.txt" ]; then
    sudo cp requirements.txt /opt/nids_agent/
    sudo python3 -m pip install -r /opt/nids_agent/requirements.txt
fi

sudo chmod +x /opt/nids_agent/nids_bridge.py

echo "✅ Installation complete! Run the agent using:"
echo "sudo python3 /opt/nids_agent/nids_bridge.py"
